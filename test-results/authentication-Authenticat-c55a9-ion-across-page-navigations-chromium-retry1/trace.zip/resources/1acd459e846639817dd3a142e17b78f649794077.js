(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_b5b61851._.js",
  "static/chunks/_73bef5ad._.js",
  "static/chunks/node_modules_cd1ac213._.js"
],
    source: "dynamic"
});
