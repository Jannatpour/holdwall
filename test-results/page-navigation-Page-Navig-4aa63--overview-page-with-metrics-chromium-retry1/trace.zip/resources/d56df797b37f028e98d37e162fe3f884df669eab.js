(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/next-auth/react.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/node_modules/next-auth/react.js [app-client] (ecmascript)");
    });
});
}),
"[project]/components/overview-data.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/components_0bf4ed2d._.js",
  "static/chunks/node_modules_7292cd68._.js",
  "static/chunks/components_overview-data_tsx_a2d29598._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/overview-data.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);