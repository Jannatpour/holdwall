(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__7c658417._.css",
  "static/chunks/lib_pwa_b9ab1ffa._.js",
  "static/chunks/_9fc7d43f._.js",
  "static/chunks/node_modules_7fb86118._.js"
],
    source: "dynamic"
});
