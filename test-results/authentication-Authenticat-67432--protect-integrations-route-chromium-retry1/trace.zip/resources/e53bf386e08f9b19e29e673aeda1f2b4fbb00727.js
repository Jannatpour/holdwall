(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next-auth_react_2c2fc08f.js",
  "static/chunks/_d80bff2e._.js",
  "static/chunks/node_modules_fb3924ae._.js"
],
    source: "dynamic"
});
